```python
?code=printf(`c\at+/fffffffffflagafag`);

```