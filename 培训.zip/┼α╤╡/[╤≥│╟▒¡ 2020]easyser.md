`robots.txt`

`http://node4.anna.nssctf.cn:28757/star1.php/star1.php?path=http://127.0.0.1/star1.php
